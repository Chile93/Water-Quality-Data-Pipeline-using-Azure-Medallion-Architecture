from pyspark import pipelines as dp
from pyspark.sql.functions import col, when

# Configure Azure Storage credentials
adls_storage_name = "waterqualityadlsgen22"
adls_storage_access_key = "7xOPPgCD6UOqt244D2KAPdjVBwdzWyzYvUnjOJEVNAc4qUwT/QEGob7bGDr9g+/hKAvLB1uhodhX+AStZ18YqA=="

spark.conf.set(
    "fs.azure.account.key." + adls_storage_name + ".blob.core.windows.net",
    adls_storage_access_key
)

# Bronze Layer
@dp.table(
    name="bronze.bronze_water_quality2",
    comment="Raw ingested water quality data"
)
@dp.expect_or_drop("valid_uid", "UID IS NOT NULL")
@dp.expect_or_drop("valid_site", "monitoringSiteIdentifier IS NOT NULL")
def bronze():
    return (
        spark.read.format("json").load(
            "wasbs://adlsdata@waterqualityadlsgen22.blob.core.windows.net/"
        )
    )

# Silver Layer
@dp.table(
    name="silver.silver_water_quality2",
    comment="Cleaned and conformed water quality data"
)
@dp.expect_or_drop("valid_year", "Reference_Year IS NOT NULL")
def silver():
    df = spark.read.table("bronze.bronze_water_quality2")
    # Data Cleaning and Transformation
    silver_df = (
        df.drop(
            "monitoringSiteIdentifierScheme", "observedPropertyDeterminandCode", "procedureAnalyticalMethod",
            "parameterSampleDepth", "resultObservationStatus", "remarks", "metadata_beginLifeSpanVersion",
            "metadata_statusCode", "metadata_observationStatus", "metadata_statements", "metadata_versionId",
            "resultStandardDeviationValue"
        )
        .withColumnRenamed("countryCode", "Country_Code")
        .withColumnRenamed("monitoringSiteIdentifier", "Monitoring_SiteID")
        .withColumnRenamed("parameterWaterBodyCategory", "Water_Body")
        .withColumnRenamed("observedPropertyDeterminandLabel", "Determinand_Label")
        .withColumnRenamed("procedureAnalysedMatrix", "Analyzed_Matrix")
        .withColumnRenamed("resultUom", "Result_Unit")
        .withColumnRenamed("phenomenonTimeReferenceYear", "Reference_Year")
        .withColumnRenamed("parameterSamplingPeriod", "Sampling_Period")
        .withColumnRenamed("procedureLOQValue", "LOQ_Value")
        .withColumnRenamed("resultNumberOfSamples", "Num_of_Samples")
        .withColumnRenamed("resultQualityNumberOfSamplesBelowLOQ", "Quality_Samples")
        .withColumnRenamed("resultQualityMinimumBelowLOQ", "Quality_MinimumValue")
        .withColumnRenamed("resultMinimumValue", "Minimum_Value")
        .withColumnRenamed("resultQualityMeanBelowLOQ", "Quality_Meanvalue")
        .withColumnRenamed("resultMeanValue", "Mean_Value")
        .withColumnRenamed("resultQualityMaximumBelowLOQ", "Quality_MaximumValue")
        .withColumnRenamed("resultMaximumValue", "Maximum_value")
        .withColumnRenamed("resultQualityMedianBelowLOQ", "Quality_MedianValue")
        .withColumnRenamed("resultMedianValue", "Median_Value")
    )

    country_name_expr = (
        when(col("Country_Code") == "AT", "Austria")
        .when(col("Country_Code") == "CZ", "Czech Republic")
        .when(col("Country_Code") == "DE", "Germany")
        .when(col("Country_Code") == "BE", "Belgium")
        .when(col("Country_Code") == "ES", "Spain")
        .when(col("Country_Code") == "SK", "Slovakia")
        .when(col("Country_Code") == "SE", "Sweden")
        .when(col("Country_Code") == "DK", "Denmark")
        .when(col("Country_Code") == "IE", "Ireland")
        .when(col("Country_Code") == "CH", "Switzerland")
        .when(col("Country_Code") == "RO", "Romania")
        .when(col("Country_Code") == "EL", "Greece")
        .when(col("Country_Code") == "NO", "Norway")
        .when(col("Country_Code") == "BG", "Bulgaria")
        .when(col("Country_Code") == "SI", "Slovenia")
        .when(col("Country_Code") == "FR", "France")
        .when(col("Country_Code") == "IT", "Italy")
        .when(col("Country_Code") == "PL", "Poland")
        .when(col("Country_Code") == "LT", "Lithuania")
        .when(col("Country_Code") == "HR", "Croatia")
        .when(col("Country_Code") == "RS", "Serbia")
        .when(col("Country_Code") == "LV", "Latvia")
        .when(col("Country_Code") == "CY", "Cyprus")
        .when(col("Country_Code") == "AL", "Albania")
        .when(col("Country_Code") == "MK", "North Macedonia")
        .when(col("Country_Code") == "BA", "Bosnia and Herzegovina")
        .when(col("Country_Code") == "MT", "Malta")
        .when(col("Country_Code") == "FI", "Finland")
        .when(col("Country_Code") == "XK", "Kosovo")
        .when(col("Country_Code") == "EE", "Estonia")
        .when(col("Country_Code") == "TR", "Turkey")
        .when(col("Country_Code") == "LU", "Luxembourg")
        .when(col("Country_Code") == "HU", "Hungary")
        .when(col("Country_Code") == "PT", "Portugal")
        .when(col("Country_Code") == "NL", "Netherlands")
        .when(col("Country_Code") == "IS", "Iceland")
        .when(col("Country_Code") == "LI", "Liechtenstein")
        .when(col("Country_Code") == "ME", "Montenegro")
        .otherwise("Unknown")
    )

    silver_df = silver_df.withColumn("Country_Name", country_name_expr)
    silver_df = silver_df.drop("Country_Code")
    return silver_df

# Gold Layer
@dp.table(
    name="gold.gold_water_quality2",
    comment="Aggregated water quality metrics for reporting"
)
def gold():
    df = spark.read.table("silver.silver_water_quality2")
    return (
        df.dropDuplicates()
          .withColumn("Start_Date", col("Sampling_Period").substr(1, 10))
          .withColumn("End_Date", col("Sampling_Period").substr(-10, 10))
    )