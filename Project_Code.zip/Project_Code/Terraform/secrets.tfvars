sql_password              = "<SQL-Password>"
azure_ad_admin_user       = "<azure-account-user-email>"
azure_ad_admin_object_id  = "<azure-object-user-id>"
my_public_ip              = "<your-ip>"
